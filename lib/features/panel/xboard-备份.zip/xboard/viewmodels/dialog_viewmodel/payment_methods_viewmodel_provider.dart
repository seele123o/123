// lib/features/panel/xboard/viewmodels/dialog_viewmodel/payment_methods_viewmodel_provider.dart
import 'package:hooks_riverpod/hooks_riverpod.dart';
import './payment_methods_viewmodel.dart';

final paymentMethodsViewModelProvider = ChangeNotifierProvider.autoDispose.family<PaymentMethodsViewModel, PaymentMethodsViewModelParams>(
  (ref, params) => PaymentMethodsViewModel(
    orderId: params.orderId,
    paymentSystem: ref.watch(paymentSystemProvider),
    orderService: ref.watch(orderServiceProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  ),
);
// 支付状态提供者
final paymentStateProvider = StateNotifierProvider.autoDispose<PaymentStateNotifier, PaymentState>((ref) {
  return PaymentStateNotifier();
});

// 支付状态
class PaymentState {
  final bool isProcessing;
  final String? error;
  final PaymentProvider? selectedProvider;
  final Map<String, dynamic>? paymentData;

  PaymentState({
    this.isProcessing = false,
    this.error,
    this.selectedProvider,
    this.paymentData,
  });
}

// 支付状态管理器
class PaymentStateNotifier extends StateNotifier<PaymentState> {
  PaymentStateNotifier() : super(PaymentState());

  void setProcessing(bool isProcessing) {
    state = PaymentState(
      isProcessing: isProcessing,
      error: state.error,
      selectedProvider: state.selectedProvider,
      paymentData: state.paymentData,
    );
  }

  void setError(String? error) {
    state = PaymentState(
      isProcessing: state.isProcessing,
      error: error,
      selectedProvider: state.selectedProvider,
      paymentData: state.paymentData,
    );
  }

  void setSelectedProvider(PaymentProvider provider) {
    state = PaymentState(
      isProcessing: state.isProcessing,
      error: state.error,
      selectedProvider: provider,
      paymentData: state.paymentData,
    );
  }

  void setPaymentData(Map<String, dynamic> data) {
    state = PaymentState(
      isProcessing: state.isProcessing,
      error: state.error,
      selectedProvider: state.selectedProvider,
      paymentData: data,
    );
  }

  void reset() {
    state = PaymentState();
  }
}
