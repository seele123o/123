import 'dart:async';
import 'package:flutter/material.dart';
import '../models/user_info_model.dart';
import '../services/http_service/user_service.dart';
import '../core/storage/xboard_cache_manager.dart';
import '../core/error/error_handler.dart';
import '../core/analytics/analytics_service.dart';
import '../core/notifications/notification_service.dart';

class UserInfoViewModel extends ChangeNotifier {
  final UserService _userService;
  final XboardCacheManager _cacheManager;
  final ErrorHandler _errorHandler;
  final AnalyticsService _analytics;
  final NotificationService _notifications;

  // 基础状态
  UserInfo? _userInfo;
  bool _isLoading = false;
  bool _isRefreshing = false;
  String? _error;

  // 自动刷新控制
  Timer? _autoRefreshTimer;
  Timer? _expiryCheckTimer;
  static const Duration _refreshInterval = Duration(minutes: 5);
  static const Duration _expiryCheckInterval = Duration(minutes: 30);

  // 数据监控阈值
  static const double _dataWarningThreshold = 0.8;
  static const Duration _expiryWarningThreshold = Duration(days: 7);

  // Getters
  UserInfo? get userInfo => _userInfo;
  bool get isLoading => _isLoading;
  bool get isRefreshing => _isRefreshing;
  String? get error => _error;

  UserInfoViewModel({
    required UserService userService,
    required XboardCacheManager cacheManager,
    required ErrorHandler errorHandler,
    required AnalyticsService analytics,
    required NotificationService notifications,
  })  : _userService = userService,
        _cacheManager = cacheManager,
        _errorHandler = errorHandler,
        _analytics = analytics,
        _notifications = notifications {
    _initializeTimers();
    _loadInitialData();
  }

  void _initializeTimers() {
    _autoRefreshTimer = Timer.periodic(_refreshInterval, (_) => _autoRefresh());
    _expiryCheckTimer = Timer.periodic(_expiryCheckInterval, (_) => _checkSubscriptionStatus());
  }

  Future<void> _loadInitialData() async {
    try {
      final cachedInfo = await _cacheManager.getCachedData<UserInfo>(
        key: 'user_info',
        fromJson: UserInfo.fromJson,
      );

      if (cachedInfo != null) {
        _userInfo = cachedInfo;
        notifyListeners();
      }

      await refreshUserInfo(showLoadingIndicator: !cachedInfo?.isCached ?? true);
    } catch (e) {
      _errorHandler.handleError(e);
    }
  }

  Future<void> refreshUserInfo({bool showLoadingIndicator = true}) async {
    if (_isRefreshing) return;

    if (showLoadingIndicator) {
      _isLoading = true;
      notifyListeners();
    }

    _isRefreshing = true;
    try {
      _userInfo = await _userService.fetchUserInfo();
      _error = null;

      // 检查并发出警告
      _checkDataUsage();
      _checkExpiryStatus();

      // 记录分析数据
      _analytics.logEvent('user_info_refreshed', {
        'has_subscription': _userInfo?.hasActiveSubscription,
        'data_usage': _userInfo?.calculateDataUsagePercentage(),
      });
    } catch (e) {
      _error = _errorHandler.handleError(e);
      _analytics.logError('user_info_refresh_failed', e);
    } finally {
      _isLoading = false;
      _isRefreshing = false;
      notifyListeners();
    }
  }

  void _checkDataUsage() {
    if (_userInfo == null) return;
    final usagePercentage = _userInfo!.calculateDataUsagePercentage();

    if (usagePercentage >= _dataWarningThreshold) {
      _notifications.show(
        title: '流量使用警告',
        body: '您已使用${(usagePercentage * 100).toStringAsFixed(1)}%的流量配额',
        type: NotificationType.warning,
      );
    }
  }

  void _checkExpiryStatus() {
    if (_userInfo?.subscriptionEndDate == null) return;

    final endDate = DateTime.fromMillisecondsSinceEpoch(_userInfo!.subscriptionEndDate!);
    final remaining = endDate.difference(DateTime.now());

    if (remaining <= _expiryWarningThreshold && remaining.isPositive) {
      _notifications.show(
        title: '订阅即将到期',
        body: '您的订阅将在${remaining.inDays}天后到期',
        type: NotificationType.warning,
      );
    }
  }

  Future<void> _autoRefresh() async {
    await refreshUserInfo(showLoadingIndicator: false);
  }

  void _checkSubscriptionStatus() {
    if (_userInfo?.hasActiveSubscription != true) return;

    if (_userInfo?.subscriptionEndDate != null) {
      final now = DateTime.now();
      final endDate = DateTime.fromMillisecondsSinceEpoch(_userInfo!.subscriptionEndDate!);

      if (now.isAfter(endDate)) {
        _notifications.show(
          title: '订阅已过期',
          body: '您的订阅已经过期，请及时续费以继续使用服务',
          type: NotificationType.alert,
        );
      }
    }
  }

  // 工具方法
  String formatDataUsage(int bytes) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    double size = bytes.toDouble();
    var unitIndex = 0;

    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }

    return '${size.toStringAsFixed(2)} ${units[unitIndex]}';
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _expiryCheckTimer?.cancel();
    super.dispose();
  }
}
