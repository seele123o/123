// viewmodels/login_viewmodel.dart
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_provider.dart';
import '../services/http_service/auth_service.dart';
import '../services/http_service/http_service.dart'; // 添加
import '../services/subscription.dart';
import '../utils/storage/token_storage.dart';
import '../core/config/payment_config.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:shared_preferences.dart';

class LoginViewModel extends ChangeNotifier {
  final AuthService _authService;
  final HttpService _httpService; // 添加

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  bool _isRememberMe = false;
  bool get isRememberMe => _isRememberMe;

  String? _error; // 添加
  String? get error => _error; // 添加

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  LoginViewModel({
    required AuthService authService,
    HttpService? httpService, // 添加
  })  : _authService = authService,
        _httpService = httpService ?? HttpService() {
    // 添加
    _loadSavedCredentials();
  }

  // 现有的 _loadSavedCredentials 和 _saveCredentials 保持不变

  void toggleRememberMe(bool value) {
    _isRememberMe = value;
    notifyListeners();
  }

  Future<void> login(
    String email,
    String password,
    BuildContext context,
    WidgetRef ref,
  ) async {
    _isLoading = true;
    _error = null; // 添加
    notifyListeners();

    try {
      // 添加域名检查
      if (kDebugMode) {
        print('正在检查服务器连接...');
      }

      await _httpService.initialize();

      if (kDebugMode) {
        print('服务器连接正常，开始登录...');
      }

      final result = await _authService.login(email, password);

      String? authData;
      String? token;

      void findAuthData(Map<String, dynamic> json) {
        json.forEach((key, value) {
          if (key == 'auth_data' && value is String) {
            authData = value;
          }
          if (key == 'token' && value is String) {
            token = value;
          }
          if (value is Map<String, dynamic>) {
            findAuthData(value);
          }
        });
      }

      findAuthData(result);

      if (authData != null && token != null) {
        // 存储认证令牌
        await storeToken(authData!);

        // 处理支付相关令牌
        if (result['stripe_token'] != null) {
          await storeStripeToken(result['stripe_token']);
        }
        if (result['revenuecat_token'] != null) {
          await storeRevenueCatToken(result['revenuecat_token']);
        }

        await _saveCredentials();

        // 初始化支付配置
        await PaymentConfig.getConfig();

        // 更新订阅状态
        await Subscription.updateSubscription(context, ref);

        // 更新认证状态
        ref.read(authProvider.notifier).state = true;
      } else {
        throw Exception("认证数据无效");
      }
    } catch (e) {
      if (e is ConnectionException) {
        // 添加
        _error = '无法连接到服务器，请检查网络连接';
      } else {
        _error = '登录失败：${e.toString()}';
      }
      if (kDebugMode) {
        print('登录错误: $_error');
      }
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // 清除错误信息
  void clearError() {
    // 添加
    _error = null;
    notifyListeners();
  }

  // 清理登出
  Future<void> cleanup() async {
    await clearAllTokens();
    await PaymentConfig.clearConfig();
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}
