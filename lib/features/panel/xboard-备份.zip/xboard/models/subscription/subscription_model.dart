// lib/features/panel/xboard/models/subscription_model.dart
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:json_annotation/json_annotation.dart';

// 需要添加部分
part 'subscription_model.freezed.dart';
part 'subscription_model.g.dart';  // 用于JSON序列化


@freezed
class SubscriptionModel with _$SubscriptionModel {
  const SubscriptionModel._();

  const factory SubscriptionModel({
    required String id,
    required bool isActive,
    required String planName,
    DateTime? expiryDate,
    String? currentPackageId,
    String? currentSubscriptionId,
    String? subscriptionStatus,
    String? paymentMethod,
    double? dataUsed,
    double? dataLimit,
    double? price,
    String? currency,
    String? billingPeriod,
    Map<String, dynamic>? features,
    String? webPageUrl,
    String? supportUrl,
    String? revenueCatUserId,
    String? revenueCatOffering,
    bool? autoRenewEnabled,
  }) = _SubscriptionModel;

  factory SubscriptionModel.fromJson(Map<String, dynamic> json) {
    return SubscriptionModel(
      id: json['id'] as String,
      isActive: json['is_active'] as bool,
      planName: json['plan_name'] as String,
      expiryDate: json['expiry_date'] != null
        ? DateTime.fromMillisecondsSinceEpoch(json['expiry_date'] as int)
        : null,
      currentPackageId: json['current_package_id'] as String?,
      currentSubscriptionId: json['current_subscription_id'] as String?,
      subscriptionStatus: json['subscription_status'] as String?,
      paymentMethod: json['payment_method'] as String?,
      dataUsed: (json['data_used'] as num?)?.toDouble(),
      dataLimit: (json['data_limit'] as num?)?.toDouble(),
      price: (json['price'] as num?)?.toDouble(),
      currency: json['currency'] as String?,
      billingPeriod: json['billing_period'] as String?,
      features: json['features'] as Map<String, dynamic>?,
      webPageUrl: json['web_page_url'] as String?,
      supportUrl: json['support_url'] as String?,
      revenueCatUserId: json['revenuecat_user_id'] as String?,
      revenueCatOffering: json['revenuecat_offering'] as String?,
      autoRenewEnabled: json['auto_renew_enabled'] as bool?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'is_active': isActive,
      'plan_name': planName,
      'expiry_date': expiryDate?.millisecondsSinceEpoch,
      'current_package_id': currentPackageId,
      'current_subscription_id': currentSubscriptionId,
      'subscription_status': subscriptionStatus,
      'payment_method': paymentMethod,
      'data_used': dataUsed,
      'data_limit': dataLimit,
      'price': price,
      'currency': currency,
      'billing_period': billingPeriod,
      'features': features,
      'web_page_url': webPageUrl,
      'support_url': supportUrl,
      'revenuecat_user_id': revenueCatUserId,
      'revenuecat_offering': revenueCatOffering,
      'auto_renew_enabled': autoRenewEnabled,
    };
  }

  // RevenueCat 相关
  factory SubscriptionModel.fromCustomerInfo(CustomerInfo customerInfo) {
    final active = customerInfo.entitlements.active;
    final latest = active.isNotEmpty ? active.values.first : null;

    return SubscriptionModel(
      id: customerInfo.originalAppUserId,
      isActive: active.isNotEmpty,
      planName: latest?.identifier ?? 'Unknown Plan',
      expiryDate: latest?.expirationDate,
      currentPackageId: latest?.productIdentifier,
      subscriptionStatus: latest?.isActive == true ? 'active' : 'inactive',
      revenueCatUserId: customerInfo.originalAppUserId,
      autoRenewEnabled: latest?.willRenew ?? false,
    );
  }

  // 便捷方法
  bool get hasActiveSubscription => isActive && (expiryDate?.isAfter(DateTime.now()) ?? false);

  double get dataUsagePercentage =>
    dataLimit != null && dataLimit! > 0 ? (dataUsed ?? 0) / dataLimit! : 0.0;

  Duration get remainingDays =>
    expiryDate?.difference(DateTime.now()) ?? Duration.zero;

  bool get isExpiringSoon =>
    hasActiveSubscription && remainingDays.inDays <= 7;
}

@freezed
class BillingHistory with _$BillingHistory {
  const factory BillingHistory({
    required String id,
    required DateTime date,
    required double amount,
    required String currency,
    required String description,
    required String status,
    String? transactionId,
    String? paymentMethod,
    bool? isRefunded,
    Map<String, dynamic>? metadata,
  }) = _BillingHistory;

  factory BillingHistory.fromJson(Map<String, dynamic> json) {
    return BillingHistory(
      id: json['id'] as String,
      date: DateTime.fromMillisecondsSinceEpoch(json['date'] as int),
      amount: (json['amount'] as num).toDouble(),
      currency: json['currency'] as String,
      description: json['description'] as String,
      status: json['status'] as String,
      transactionId: json['transaction_id'] as String?,
      paymentMethod: json['payment_method'] as String?,
      isRefunded: json['is_refunded'] as bool?,
      metadata: json['metadata'] as Map<String, dynamic>?,
    );
  }
}