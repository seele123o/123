// lib/features/panel/xboard/services/auth_provider.dart
import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../core/storage/xboard_cache_manager.dart';
import '../core/storage/xboard_storage_config.dart';
import '../utils/storage/token_storage.dart';
import '../models/user_info_model.dart';
import './http_service/user_service.dart';
import './payment/payment_system.dart'; // 添加 payment_system 导入

// 认证状态类
class AuthState {
  final bool isAuthenticated;
  final bool isLoading;
  final String? error;
  final UserInfo? userInfo;
  final bool isPaymentInitialized; // 新增支付初始化状态

  AuthState({
    this.isAuthenticated = false,
    this.isLoading = false,
    this.error,
    this.userInfo,
    this.isPaymentInitialized = false, // 初始化为 false
  });

  AuthState copyWith({
    bool? isAuthenticated,
    bool? isLoading,
    String? error,
    UserInfo? userInfo,
    bool? isPaymentInitialized,
  }) {
    return AuthState(
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      userInfo: userInfo ?? this.userInfo,
      isPaymentInitialized: isPaymentInitialized ?? this.isPaymentInitialized,
    );
  }
}

// 认证状态管理器
class AuthNotifier extends StateNotifier<AuthState> {
  final XboardCacheManager _cacheManager;
  final UserService _userService;
  final PaymentSystem _paymentSystem; // 新增 PaymentSystem

  AuthNotifier({
    required XboardCacheManager cacheManager,
    required UserService userService,
    required PaymentSystem paymentSystem, // 注入 PaymentSystem
  })  : _cacheManager = cacheManager,
        _userService = userService,
        _paymentSystem = paymentSystem,
        super(AuthState());

  // 初始化认证和支付系统
  Future<void> initAuth() async {
    state = state.copyWith(isLoading: true);

    try {
      final token = await getToken();
      if (token == null) {
        state = AuthState(isAuthenticated: false);
        return;
      }

      // 尝试从缓存获取用户信息
      final cachedUser = await _cacheManager.getCachedData<UserInfo>(
        key: XboardStorageConfig.userInfoKey,
        fromJson: UserInfo.fromJson,
      );

      if (cachedUser != null) {
        state = AuthState(
          isAuthenticated: true,
          userInfo: cachedUser,
        );

        // 初始化支付系统
        await _initializePaymentSystem(cachedUser);

        // 在后台刷新用户信息
        _refreshUserInfo(token);
      } else {
        await _refreshUserInfo(token);
      }
    } catch (e) {
      await logout();
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  // 后台刷新用户信息
  Future<void> _refreshUserInfo(String token) async {
    try {
      final userInfo = await _userService.fetchUserInfo(token);
      await _cacheManager.cacheData(
        key: XboardStorageConfig.userInfoKey,
        data: userInfo,
        duration: XboardStorageConfig.userInfoCacheDuration,
      );

      state = state.copyWith(
        isAuthenticated: true,
        userInfo: userInfo,
      );

      // 刷新用户信息后初始化支付系统
      await _initializePaymentSystem(userInfo);
    } catch (e) {
      // 如果是后台刷新，失败不影响当前状态
      if (!state.isAuthenticated) {
        await logout();
      }
    }
  }

  Future<void> linkSubscription(String token) async {
    try {
      final result = await _httpService.postRequest(
        '/api/v1/user/subscription/link',
        {'token': token},
        headers: {'Authorization': await getToken() ?? ''},
      );

      if (result['status'] != 'success') {
        throw AuthenticationException(result['message']);
      }
    } catch (e) {
      _analytics.logError('link_subscription_failed', e);
      rethrow;
    }
  }

  // 初始化支付系统
  Future<void> _initializePaymentSystem(UserInfo userInfo) async {
    if (state.isPaymentInitialized) return; // 避免重复初始化

    try {
      await _paymentSystem.initialize();
      state = state.copyWith(isPaymentInitialized: true);
    } catch (e) {
      print('支付系统初始化失败: $e');
      // 支付系统初始化失败不影响主流程
    }
  }

  // 更新登出方法
  Future<void> logout() async {
    try {
      // 清理支付系统状态
      if (state.isPaymentInitialized) {
        await _paymentSystem.cleanup();
      }

      await deleteToken();
      await _cacheManager.clearAllCache();
      state = AuthState(isAuthenticated: false);
    } catch (e) {
      print('登出过程发生错误: $e');
      // 确保状态被重置
      state = AuthState(isAuthenticated: false);
    }
  }
}

// Providers
final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    cacheManager: XboardCacheManager(),
    userService: UserService(),
    paymentSystem: ref.watch(paymentSystemProvider), // 使用 PaymentSystem provider
  );
});

// 辅助函数：登出
Future<void> logout(BuildContext context, WidgetRef ref) async {
  await ref.read(authStateProvider.notifier).logout();
  if (context.mounted) {
    context.go('/');
  }
}
