// lib/features/panel/xboard/services/http_service/order_service.dart
import '../../../models/order_model.dart';
import './http_service.dart';
import '../payment/payment_system.dart';
import '../payment/payment_exceptions.dart';

class OrderService {
  final HttpService _httpService;
  final PaymentSystem _paymentSystem;

  OrderService({
    HttpService? httpService,
    PaymentSystem? paymentSystem,
  })  : _httpService = httpService ?? HttpService(),
        _paymentSystem = paymentSystem ??
            PaymentSystem(
              orderService: OrderService(),
              stripeService: StripeService(),
              revenueCatService: RevenueCatService(),
            );

  // 创建订单
  Future<Map<String, dynamic>> createOrder(
    String planId,
    String paymentProvider,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.postRequest(
        '/api/v1/order/create',
        {
          'plan_id': planId,
          'payment_provider': paymentProvider,
        },
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to create order',
          code: result['code'] ?? '',
          details: result['data'],
        );
      }

      // 预初始化对应的支付提供商
      final provider = PaymentProvider.fromString(paymentProvider);
      await _paymentSystem.initializeProvider(provider);

      return result;
    } catch (e) {
      throw PaymentException(
        'Order creation failed: ${e.toString()}',
      );
    }
  }

  // 获取用户订单列表
  Future<List<Order>> fetchUserOrders(String accessToken) async {
    final result = await _httpService.getRequest(
      "/api/v1/user/order/fetch",
      headers: {'Authorization': accessToken},
    );

    if (result["status"] == "success") {
      final ordersJson = result["data"] as List;
      return ordersJson.map((json) => Order.fromJson(json as Map<String, dynamic>)).toList();
    } else {
      throw PaymentException(
        "Failed to fetch user orders: ${result['message']}",
        code: result['code'] ?? '',
      );
    }
  }

  // Stripe支付相关
  Future<Map<String, dynamic>> createStripePaymentIntent(
    String orderId,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.postRequest(
        "/api/v1/user/order/stripe/create-payment-intent",
        {"order_id": orderId},
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to create payment intent',
          code: result['code'] ?? '',
          details: result['data'],
        );
      }

      return result['data'];
    } catch (e) {
      throw PaymentException('Failed to create Stripe payment: $e');
    }
  }

  Future<Map<String, dynamic>> confirmStripePayment(
    String orderId,
    String paymentIntentId,
    String accessToken,
  ) async {
    try {
      return await _httpService.postRequest(
        "/api/v1/user/order/stripe/confirm-payment",
        {
          "order_id": orderId,
          "payment_intent_id": paymentIntentId,
        },
        headers: {'Authorization': accessToken},
      );
    } catch (e) {
      throw PaymentException('Failed to confirm Stripe payment: $e');
    }
  }

  // RevenueCat支付相关
  Future<Map<String, dynamic>> createRevenueCatPurchase(
    String orderId,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.postRequest(
        "/api/v1/user/order/revenuecat/create-purchase",
        {"order_id": orderId},
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to create purchase',
          code: result['code'] ?? '',
          details: result['data'],
        );
      }

      return result['data'];
    } catch (e) {
      throw PaymentException('Failed to create RevenueCat purchase: $e');
    }
  }

  Future<Map<String, dynamic>> verifyRevenueCatPurchase(
    String orderId,
    String purchaseToken,
    String accessToken,
  ) async {
    try {
      return await _httpService.postRequest(
        "/api/v1/user/order/revenuecat/verify-purchase",
        {
          "order_id": orderId,
          "purchase_token": purchaseToken,
        },
        headers: {'Authorization': accessToken},
      );
    } catch (e) {
      throw PaymentException('Failed to verify RevenueCat purchase: $e');
    }
  }

  // 订单状态相关
  Future<Map<String, dynamic>> getOrderDetails(
    String orderId,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.getRequest(
        "/api/v1/user/order/detail/$orderId",
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to get order details',
          code: result['code'] ?? '',
        );
      }

      return result['data'];
    } catch (e) {
      throw PaymentException('Failed to get order details: $e');
    }
  }

  Future<OrderStatus> getOrderStatus(
    String orderId,
    String accessToken,
  ) async {
    final details = await getOrderDetails(orderId, accessToken);
    return OrderStatus.fromValue(details['status'] as int? ?? 0);
  }

  // 取消订单
  Future<void> cancelOrder(
    String orderId,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.postRequest(
        "/api/v1/user/order/cancel",
        {"order_id": orderId},
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to cancel order',
          code: result['code'] ?? '',
        );
      }

      // 获取订单详情以确定需要取消的支付方式
      final orderDetails = await getOrderDetails(orderId, accessToken);
      final paymentProvider = PaymentProvider.fromString(
        orderDetails['payment_provider'] ?? '',
      );

      // 通知支付系统取消相应的支付
      await _paymentSystem.cancelPayment(orderId, paymentProvider);
    } catch (e) {
      throw PaymentException('Failed to cancel order: $e');
    }
  }

  // 支付方式相关
  Future<List<PaymentProvider>> getAvailablePaymentMethods(
    String orderId,
    String accessToken,
  ) async {
    try {
      final result = await _httpService.getRequest(
        "/api/v1/user/order/payment-methods/$orderId",
        headers: {'Authorization': accessToken},
      );

      if (result['status'] != 'success') {
        throw PaymentException(
          result['message'] ?? 'Failed to get payment methods',
          code: result['code'] ?? '',
        );
      }

      final methods = (result['data'] as List).map((method) => PaymentProvider.fromString(method)).where((provider) => _paymentSystem.isProviderAvailable(provider)).toList();

      return methods;
    } catch (e) {
      throw PaymentException('Failed to get payment methods: $e');
    }
  }

  // 订阅同步
  Future<Map<String, dynamic>> syncSubscriptionStatus(
    String accessToken,
  ) async {
    try {
      return await _httpService.postRequest(
        "/api/v1/user/order/sync-subscription",
        {},
        headers: {'Authorization': accessToken},
      );
    } catch (e) {
      throw PaymentException('Failed to sync subscription status: $e');
    }
  }

  // 恢复购买
  Future<Map<String, dynamic>> restorePurchases(
    String accessToken,
  ) async {
    try {
      return await _httpService.postRequest(
        "/api/v1/user/order/restore-purchases",
        {},
        headers: {'Authorization': accessToken},
      );
    } catch (e) {
      throw PaymentException('Failed to restore purchases: $e');
    }
  }
}
