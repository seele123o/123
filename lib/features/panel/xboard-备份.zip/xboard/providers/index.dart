// lib/features/panel/xboard/providers/index.dart
import 'package:hooks_riverpod/hooks_riverpod.dart';

// 外部服务导入
import '../core/analytics/analytics_service.dart';
import '../core/config/payment_config.dart';
import '../core/error/error_handler.dart';
import '../core/storage/xboard_cache_manager.dart';

// 模型导入
import '../models/order_model.dart';
import '../models/payment_process_state.dart';
import '../models/plan_model.dart';

// HTTP 服务导入
import '../services/http_service/auth_service.dart';
import '../services/http_service/http_service.dart';
import '../services/http_service/order_service.dart';
import '../services/http_service/payment_service.dart';
import '../services/http_service/plan_service.dart';
import '../services/http_service/user_service.dart';

// 支付服务导入
import '../services/payment/payment_system.dart';
import '../services/payment/revenuecat_service.dart';
import '../services/payment/stripe_service.dart';

// 视图模型导入
import '../services/monitor_pay_status.dart';
import '../viewmodels/purchase_viewmodel.dart';
import '../viewmodels/user_info_viewmodel.dart';

// 导出必要的类型和枚举
export '../models/payment_process_state.dart' show PaymentStep;
export '../models/order_model.dart' show OrderStatus, PaymentProvider;
export '../models/plan_model.dart' show PlanSortType, PlanPeriod;
export 'package:hooks_riverpod/hooks_riverpod.dart' show AsyncValue, Provider, ProviderRef;

part 'index.g.dart';

/// 核心服务 Providers
final cacheManagerProvider = Provider<XboardCacheManager>((ref) => XboardCacheManager());
final httpServiceProvider = Provider<HttpService>((ref) => HttpService());
final errorHandlerProvider = Provider<ErrorHandler>((ref) => ErrorHandler());
final analyticsProvider = Provider<AnalyticsService>((ref) => AnalyticsService());
final configProvider = Provider<PaymentConfig>((ref) => PaymentConfig());

/// 认证相关 Providers
final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(
    httpService: ref.watch(httpServiceProvider),
    cacheManager: ref.watch(cacheManagerProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  );
});

final userServiceProvider = Provider<UserService>((ref) {
  return UserService(
    httpService: ref.watch(httpServiceProvider),
    cacheManager: ref.watch(cacheManagerProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  );
});

/// 支付相关 Providers
final stripeServiceProvider = Provider<StripeService>((ref) => StripeService());
final revenueCatServiceProvider = Provider<RevenueCatService>((ref) => RevenueCatService());

final paymentSystemProvider = Provider<PaymentSystem>((ref) {
  return PaymentSystem(
    orderService: ref.watch(orderServiceProvider),
    stripeService: ref.watch(stripeServiceProvider),
    revenueCatService: ref.watch(revenueCatServiceProvider),
  );
});

final paymentServiceProvider = Provider<PaymentService>((ref) {
  return PaymentService(
    httpService: ref.watch(httpServiceProvider),
    paymentSystem: ref.watch(paymentSystemProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  );
});

final orderServiceProvider = Provider<OrderService>((ref) {
  return OrderService(
    httpService: ref.watch(httpServiceProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  );
});

/// 计划相关 Providers
final planServiceProvider = Provider<PlanService>((ref) {
  return PlanService(
    httpService: ref.watch(httpServiceProvider),
    cacheManager: ref.watch(cacheManagerProvider),
    errorHandler: ref.watch(errorHandlerProvider),
  );
});

/// 支付监控 Provider
final monitorPayStatusProvider = Provider.autoDispose((ref) {
  return MonitorPayStatus(
    orderService: ref.watch(orderServiceProvider),
  );
});

/// 状态和计划 Providers
final planProvider = FutureProvider.family<Plan?, int>((ref, planId) async {
  final cacheManager = ref.watch(cacheManagerProvider);
  final cacheKey = 'plan_$planId';

  try {
    // 尝试从缓存获取
    final cachedPlan = await cacheManager.getCachedData<Plan>(
      key: cacheKey,
      fromJson: (json) => Plan.fromJson(json),
    );

    if (cachedPlan != null) {
      return cachedPlan;
    }

    // 从服务器获取
    final planService = ref.watch(planServiceProvider);
    final plans = await planService.fetchPlanData();
    final plan = plans.firstWhere(
      (p) => p.id == planId,
      orElse: () => throw Exception('Plan not found'),
    );

    // 缓存计划数据
    await cacheManager.cacheData(
      key: cacheKey,
      data: plan,
      duration: const Duration(hours: 12),
    );

    return plan;
  } catch (e) {
    ref.read(errorHandlerProvider).handleError(e);
    rethrow;
  }
});

/// 支付流程状态 Provider
final paymentProcessStateProvider = StateNotifierProvider<PaymentProcessNotifier, PaymentProcessState>((ref) {
  return PaymentProcessNotifier();
});

/// ViewModel Providers
final purchaseViewModelProvider = ChangeNotifierProvider((ref) {
  return PurchaseViewModel(
    purchaseService: ref.watch(purchaseServiceProvider),
    paymentService: ref.watch(paymentServiceProvider),
    cacheManager: ref.watch(cacheManagerProvider),
    errorHandler: ref.watch(errorHandlerProvider),
    analytics: ref.watch(analyticsProvider),
    config: ref.watch(configProvider),
  );
});

final userInfoViewModelProvider = ChangeNotifierProvider((ref) {
  return UserInfoViewModel(
    userService: ref.watch(userServiceProvider),
    cacheManager: ref.watch(cacheManagerProvider),
    errorHandler: ref.watch(errorHandlerProvider),
    analytics: ref.watch(analyticsProvider),
  );
});

/// 状态管理 Provider
final loadingStateProvider = StateProvider<bool>((ref) => false);
final errorStateProvider = StateProvider<String?>((ref) => null);

