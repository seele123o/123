// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'purchase_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$purchaseServiceHash() => r'7440c3b7113ca7059d3b6e4dbe134002dfd4d1f9';

/// See also [PurchaseService].
@ProviderFor(PurchaseService)
final purchaseServiceProvider =
    AutoDisposeAsyncNotifierProvider<PurchaseService, PurchaseState>.internal(
  PurchaseService.new,
  name: r'purchaseServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$purchaseServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PurchaseService = AutoDisposeAsyncNotifier<PurchaseState>;
String _$purchaseStateNotifierHash() =>
    r'1bd13be3ce19b17c156a7da694e717dd8d912640';

/// See also [PurchaseStateNotifier].
@ProviderFor(PurchaseStateNotifier)
final purchaseStateNotifierProvider =
    AutoDisposeNotifierProvider<PurchaseStateNotifier, PurchaseState>.internal(
  PurchaseStateNotifier.new,
  name: r'purchaseStateNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$purchaseStateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PurchaseStateNotifier = AutoDisposeNotifier<PurchaseState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
