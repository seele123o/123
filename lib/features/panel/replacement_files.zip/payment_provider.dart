
enum PaymentProvider {
  stripe,
  paypal,
  revenuecat,
  others;  // Add any other payment providers as needed
}
